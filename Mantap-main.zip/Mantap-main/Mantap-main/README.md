<h2 align="center">
Auto Script Install All VPN Service
Mod By Faruk Browser
<img src="https://img.shields.io/badge/Version-1.0.0-blue.svg"></h2>
<p align="center">
</p> 
<h2 align="center"> Supported Linux Distribution</h2>
<p align="center"><img src="https://d33wubrfki0l68.cloudfront.net/5911c43be3b1da526ed609e9c55783d9d0f6b066/9858b/assets/img/debian-ubuntu-hover.png"></p> 
<p align="center"><img src="https://img.shields.io/static/v1?style=for-the-badge&logo=debian&label=Debian%209&message=Stretch&color=purple"> <img src="https://img.shields.io/static/v1?style=for-the-badge&logo=debian&label=Debian%2010&message=Buster&color=purple">  <img src="https://img.shields.io/static/v1?style=for-the-badge&logo=ubuntu&label=Ubuntu%2018&message=Lts&color=red"> <img src="https://img.shields.io/static/v1?style=for-the-badge&logo=ubuntu&label=Ubuntu%2020&message=Lts&color=red">
</p>

<p align="center"><img src="https://img.shields.io/badge/Service-SSH_Over_Websocket-success.svg">  <img src="https://img.shields.io/badge/Service-OpenVPN_Over_Websocket-success.svg">  <img src="https://img.shields.io/badge/Service-SSH_Over_DNS-success.svg">  <img src="https://img.shields.io/badge/Service-SSLH-success.svg">  <img src="https://img.shields.io/badge/Service-Stunnel5-success.svg">  <img src= "https://img.shields.io/badge/Service-OHP_Open_Http_Puncher-success.svg">  <img src= "https://img.shields.io/badge/Service-SSTP_VPN-success.svg">  <img src= "https://img.shields.io/badge/Service-L2TP_VPN-success.svg">  <img src= "https://img.shields.io/badge/Service-PPTP_VPN-success.svg">
<p align="center"><img src="https://img.shields.io/badge/Service-SSH_OpenSSH-success.svg">  <img src="https://img.shields.io/badge/Service-SSH_Dropbear-success.svg">  <img src="https://img.shields.io/badge/Service-BadVPN-success.svg">  <img src="https://img.shields.io/badge/Service-OpenVPN-success.svg">  <img src="https://img.shields.io/badge/Service-Squid3-success.svg">  <img   src="https://img.shields.io/badge/Service-Webmin-success.svg">  <img src="https://img.shields.io/badge/Service-SlowDns-success.svg">  <p align="center"><img src="https://img.shields.io/badge/Service-XRAY-success.svg">  <img src="https://img.shields.io/badge/Service-XRAY_Websocket_TLS-success.svg">  <img src="https://img.shields.io/badge/Service-XRAY_VLESS_VMESS-success.svg">  <img src="https://img.shields.io/badge/Service-XRAY_gRPC_VLESS_VMESS-success.svg">  <img src="https://img.shields.io/badge/Service-XRAY_TROJAN-success.svg">  <p align="center"><img src="https://img.shields.io/badge/Service-SSR-success.svg">  <img src="https://img.shields.io/badge/Service-Trojan_Go-success.svg">  <img src="https://img.shields.io/badge/Service-WireGuard-success.svg">  <img src= "https://img.shields.io/badge/Service-Shadowsocks-success.svg">  

### Telegram Link: 
https://t.me/farukbrowser
### Info:
* PLEASE READ & IMPORTANT READING
# THIS IS A SPECIAL SCRIPT TO CREATE A VPN SERVER
Create a Fresh VPS or New VPS and Must Use User: root
* VPS ACCOUNT ROOT
* Login VPS User using root user
* How to directly enter root access

```html
sudo su
```
Or
```html
sudo -i
```
or
```html
su
```

### Tutorial On How To Install Reach me on telegram
```html
https://t.me/farukbrowser
```

## ADDITIONAL INFO, PLEASE READ
* MINIMUM 1GB RAM TO USE THIS SCRIPT
* PLEASE REMOVE PROXY SQUID IF VPS FEEL HEAVY

# Only For OS
* • Debian 10 & 9
or
* • Ubuntu 18.04 & 20.04
* Working For VPS AWS,AZURE,DO
## Installation 
## 1.
<img src="https://img.shields.io/badge/Update%20_&_%20Upgrade-green">

  ```html
apt-get update && apt-get upgrade -y && update-grub && sleep 2 && reboot
```
  
## 2.0
<img src="https://img.shields.io/badge/Login_Root%20VPS-green">

* Login to VPS and Enable Temporary Root

  
```html
sudo su
cd
cd
```

## 2.

  <img src="https://img.shields.io/badge/Create_VPS_Root_Access-green">

* Create Root Access On VPS / Root VPS
* To Allow Root And Change Password Login on VPS Google Cloud Platform, Aws, And More
   
```html
  wget -qO- -O vpsroot.sh https://raw.githubusercontent.com/farukbrowser/Mantap/main/vpsroot.sh && bash vpsroot.sh
  
```
  
### 3.

  <img src="https://img.shields.io/badge/Install_All_VPN_Services%20-green">

* Install All VPN Service /Install All VPN Service
   
```html
rm -f setup.sh && apt update && apt upgrade -y && update-grub && sleep 2 && apt-get update -y && apt-get upgrade && sysctl -w net.ipv6.conf.all.disable_ipv6=1 && sysctl -w net.ipv6.conf.default.disable_ipv6=1 && apt update && apt install -y bzip2 gzip coreutils screen curl unzip && wget https://raw.githubusercontent.com/Farukbrowser/Mantap/main/setup.sh && chmod +x setup.sh && sed -i -e 's/\r$//' setup.sh && screen -S setup ./setup.sh
  
```
  

### 4. DONE 
<img src="https://img.shields.io/badge/DONE%20-green">

* • if you can't login on vps, use the ssh port
* • 22, 2253

### Don't Forget to Follow Our Site
<a href="https://t.me/farukbrowser" target="_blank"><img id="wse-buttons-preview" src="https://cdn.trakteer.id/images/embed/trbtn-red-6.png" height="40" style="border: 0px; height: 40px;" alt="24clanTech"></a>
https://24clan.com

### 5. MENU, INFO ,UPDATE ,FIX
* to display the menu
```html
menu
```
* to update the menu and update info
```html
updatemenu
```
* automatically to fix SSLH, WS-TLS errors
```html
sl-fix
```
```html
reboot
```
* Fix SSL ERROR
* automatically to fix SSL/TLS and SUBDOMAIN Certificate errors
* fix the error in the acme domain
* to update SSL/TLS Certificate
```html
slhost && certv2ray
```
* then restart
```html
restart
```
*
*
*

### 6. FIX ERROR SSLH WS
# Auto Fix Error SSLH + WS-TLS 443
* 1 • If an error occurs in SSLH and SSH WS-TLS, use this script to fix it
```html
menu
 ```

* 2 • in the menu then select 17 (SL-FIX Menu)
```html
17
 ```

* 3 • if it's finished then reboot / restart the vps
```html
reboot
 ```

### 7. Info Websocket
* Websocket must use a subdomain / domain and have been pointed at cloudflare (CDN CLOUDFLARE)
* Without subdomain/domain it is impossible to connect with bugs originating from cloudflare
*
*
*

### 8. Edit WS SSL Port or Change SSL Port (Manual)
* change the port you want to change, if it's 443 please change the text that is 443
* after editing then save (CTRL + X + Y and enter)

```html
nano /etc/systemd/system/ws-tls.service
 ```
```html
nano /usr/local/bin/ws-tls
 ```
```html
nano /etc/default/sslh
 ```
```html
nano /etc/stunnel5/stunnel5.conf
 ```

### 100 (Fix manual) Fix Error SSLH

* Fix sslh errors on vps that don't support sslh
* specially the vps doesn't support sslh
* turn off ws-tls
```html
systemctl stop ws-tls
```
* create sslh user / edit passwd
```html
echo sslh:x:109:114::/nonexistent:/usr/sbin/nologin >> /etc/passwd
```
* note: edit passwd and move the password above vnstat

* start sslh and run
```html
systemctl start sslh
/etc/init.d/sslh start
/etc/init.d/sslh restart
```
* then start ws-tls
```html
systemctl start ws-tls
```
```html
reboot
```
*done



# SlowDNS Special Info
• SSH Over DNS (SlowDNS)
* for its speed is limited
* speed download 3 Mbps (Max Speed)
* speed upload 100+ Mbps (Max Speed)
* Support all port ssh

### Script Features

• CHECK ALL IP AND PORT (Service ALL VPN)

• SSH & OpenVPN

• SSH Over DNS (SlowDNS)

• SSH Over Websocket (Cloudflare)

• OpenVPN Over Websocket (Cloudflare)

• SSLH

• SSH CloudFront Over Websocket (Aws CloudFront Only) [OFF]

• OHP SSH & OHP Dropbear & OHP OpenVPN (OPEN HTTP PUNCHER)

• XRAY VMESS 

• XRAY VLESS

• XRAY TROJAN

• XRAY VMESS GRPC

• XRAY VLESS GRPC

• SHADOWSOCKS 

• SHADOWSOCKS OBFS

• SHADOWSOCKS xray-plugin

• SHADOWSOCKS v2ray-plugin

• SHADOWSOCKS gost-plugin

• SSR

• PPTP VPN

• L2TP VPN

• SSTP VPN

• WIREGUARD

• TROJAN GO

• Backup Data ALL Service

• Restore Data ALL Service

• Auto Fix

• Auto Update

### Os Supported

• Debian 10 & 9

• Ubuntu 18.04 & 20.04

# Service & Port

• SlowDNS                   : All Port SSH

• OpenSSH                   : 22, 2253

• Dropbear                  : 443, 109, 143, 1153

• Stunnel5                  : 443, 445, 777

• OpenVPN                   : TCP 1194, UDP 2200, SSL 990

• Websocket SSH TLS         : 443

• Websocket SSH HTTP        : 8880

• Websocket OpenVPN         : 2086

• Squid Proxy               : 3128, 8080 [OFF]

• Badvpn                    : 7100, 7200, 7300

• Nginx                     : 89

• Wireguard                 : 7070

• L2TP/IPSEC VPN            : 1701

• PPTP VPN                  : 1732

• SSTP VPN                  : 444

• Shadowsocks-R             : 1443-1543

• SS-OBFS TLS               : 2443-2543

• SS-OBFS HTTP              : 3443-3543

• XRAYS Vmess TLS           : 8443

• XRAYS Vmess None TLS      : 80

• XRAYS Vless TLS           : 8443

• XRAYS Vless None TLS      : 80

• XRAYS Trojan              : 2083

• XRAYS Vmess GRPC TLS      : 1180,3380

• XRAYS Vless GRPC TLS      : 2280,4480

• OHP SSH                   : 8181

• OHP Dropbear              : 8282

• OHP OpenVPN               : 8383

• Trojan Go                 : 2087

• CloudFront Over Websocket : [OFF]


 ### Server Information & Other Features

• Timezone                : Africa/Nigeria (GMT +7)

• Fail2Ban                : [ON]

• Dflate                  : [ON]

• IPtables                : [ON]

• Auto-Reboot             : [ON]

• IPv6                    : [OFF]

• Autoreboot On 05.00 GMT +7

• Autoreboot On 00.00 GMT +7

• Autoreboot On 12.00 GMT +7

• Autoreboot On 18.00 GMT +7

• Auto Delete Expired Account

• Full Orders For Various Services

• White Label

• Auto Fix

• Auto Update


<div height='45' align="center">
<h2>Contact me: <br>
<a href="https://github.com/farukbrowser"> <img src="https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/github.svg" height='50'> </a>
<a href="https://facebook.com/farukbrowser"> <img src="https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/facebook.svg" height='50'> </a>
<a href="https://trakteer.id/farukbrowser/tip"> <img src="https://cdn.trakteer.id/images/embed/trbtn-red-6.png" height='50'> </a>
</h2>
</div>
<h2 align="center">
<img height=150 src="https://github-readme-stats.vercel.app/api/top-langs/?username=farukbrowser&layout=compact&theme=dark">
<img height=150 src="https://github-readme-stats.vercel.app/api?username=farukbrowser&count_private=true&show_icons=true&theme=dark">
<h2 align="center">
