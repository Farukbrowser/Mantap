#!/bin/bash
clear

echo -e "STATUS RESPON WAKTU INJECK BUG,SSH,VPN"
echo -e "301/302 = berarti BUG/PAYLOAD/Port nya di BLOKIR sementara oleh ISP"
echo -e "400 – Bad Request = Berarti Ada yang salah di payload,subdomain,domain,bug,proxy"
echo -e "521 - Origin Error = Berarti masalah nya ada di subdomain/domain"
echo -e "mungkin gagal saat install certifikat nya cara atasi masalah nya buat subdomain lagi dengan cara ketik slhost lalu ketik certv2ray di vps,"
echo -e "jika berhasil lalu reboot vps ,ketik reboot"
echo -e ""
